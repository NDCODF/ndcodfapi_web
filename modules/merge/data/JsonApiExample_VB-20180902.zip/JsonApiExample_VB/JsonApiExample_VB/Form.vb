﻿Imports System.Text
Imports System.Net
Imports System.IO

Public Class Form
    Const BUF_SIZE As Integer = 1024000 ' 1M

    Private Sub 製作報表_Click(sender As Object, e As EventArgs) Handles 製作報表.Click
        Dim oDict As New Dictionary(Of String, Object)
        Dim aData() = {}
        Dim oRecord As Dictionary(Of String, Object)
        Dim oRow As DataGridViewRow
        Dim oCell As DataGridViewCell
        Dim sJson As String
        Dim sApiUrl As String

        oDict.Add("製作日期", 製作日期.Value)
        oDict.Add("製表人", 製表人.Text)

        ' 依序取出每列
        For Each oRow In 詳細資料.Rows
            If (oRow.IsNewRow()) Then
                Continue For    ' 不理會新資料列
            End If

            Array.Resize(aData, aData.Count + 1)    ' 陣列增加新儲存區
            oRecord = New Dictionary(Of String, Object) ' 存放每個欄位
            ' 依序取出每個欄位
            For Each oCell In oRow.Cells
                oRecord.Add(詳細資料.Columns(oCell.ColumnIndex).Name, oCell.Value)
            Next oCell
            aData(UBound(aData)) = oRecord  ' 存入陣列
        Next oRow

        oDict.Add("詳細資料", aData)
        oDict.Add("總筆數", aData.Count)

        sJson = Dictionary2Json(oDict)
        Debug.Print(sJson)

        If (Writer.Checked) Then
            sApiUrl = Writer_API.Text
        ElseIf (Calc.Checked) Then
            sApiUrl = Calc_API.Text
        Else
            MsgBox("請先選擇要製作 Writer 或 Calc 報表")
            Return
        End If

        SendToAPI(sApiUrl, sJson)

    End Sub

    Private Function SendToAPI(sApiURL As String, sJson As String) As Boolean
        Dim oWebequest As HttpWebRequest
        Dim oWebResponse As HttpWebResponse
        Dim oFileStream As FileStream
        Dim sByteString As Byte()
        Dim byteBuffer(BUF_SIZE) As Byte
        Dim nRead As Long
        Dim sFilter As String
        Dim oSaveFileDialog As SaveFileDialog
        Dim sSaveFile As String
        Dim nPos As Integer
        Dim sAttachment As String, sFileName As String, sExtension As String

        sByteString = Encoding.UTF8.GetBytes(sJson) ' 轉成 UTF-8 字串

        ' 送出資料
        oWebequest = WebRequest.Create(sApiURL)
        With oWebequest
            .KeepAlive = True
            .Method = "POST"
            .Timeout = 100000 ' 100 秒
            .ContentType = "application/json"
            .ContentLength = sByteString.Length
            With .GetRequestStream()
                .Write(sByteString, 0, sByteString.Length)
                .Close()
            End With
        End With

        ' 讀取
        Try
            oWebResponse = oWebequest.GetResponse()
        Catch exp As WebException
            MsgBox(exp.Message, MsgBoxStyle.Critical, "傳送錯誤")
            Return False
        End Try
        With oWebResponse
            ' 成功的話，下載檔案
            If (.StatusCode = 200) Then
                ' 取得下載檔案類型
                sFileName = "報表文件"
                Select Case .ContentType.ToLower()
                    Case "application/vnd.oasis.opendocument.text"
                        sFilter = "文字文件 (*.odt)|*.odt"
                    Case "application/vnd.oasis.opendocument.spreadsheet"
                        sFilter = "試算表 (*.ods)|*.ods"
                    Case Else
                        sAttachment = .GetResponseHeader("Content-Disposition")
                        nPos = sAttachment.IndexOf("filename=")
                        sAttachment = sAttachment.Substring(nPos + 9).Trim({""""c})
                        sFileName = Path.GetFileNameWithoutExtension(sAttachment)
                        sExtension = Path.GetExtension(sAttachment)
                        sFilter = "報表文件 (*" & sExtension & ")|*" & sExtension
                End Select

                oSaveFileDialog = New SaveFileDialog()
                With oSaveFileDialog
                    .Title = "儲存檔案"
                    .Filter = sFilter
                    .FileName = sFileName
                    If (.ShowDialog() <> DialogResult.OK) Then
                        MsgBox("您已放棄存檔", MsgBoxStyle.Exclamation, "放棄")
                        Return False
                    End If
                    sSaveFile = .FileName
                    .Dispose()
                End With

                oFileStream = New FileStream(sSaveFile, access:=FileAccess.Write, mode:=FileMode.Create)

                With .GetResponseStream()
                    nRead = -1
                    While (nRead <> 0)
                        nRead = .Read(byteBuffer, 0, byteBuffer.Length)
                        If (nRead > 0) Then
                            oFileStream.Write(byteBuffer, 0, nRead)
                        End If
                    End While
                    oFileStream.Close()
                    oFileStream.Dispose()
                    .Close()
                    .Dispose()
                End With
            End If
            .Close()
            .Dispose()
        End With

        MsgBox("檔案儲存成功", MsgBoxStyle.Information, "成功")

        Return True

    End Function

    Private Function Dictionary2Json(oDictionary As Dictionary(Of String, Object), Optional nLevel As Long = 1) As String
        Dim sJson As New StringBuilder
        Dim nCnt As Long = 0
        Dim oItem As KeyValuePair(Of String, Object)

        sJson.Append(vbTab, repeatCount:=nLevel - 1).Append("{").AppendLine()

        For Each oItem In oDictionary

            nCnt += 1

            sJson.Append(JsonElement(oItem.Key, oItem.Value, nLevel))

            If (nCnt < oDictionary.Count) Then
                sJson.Append(",").AppendLine()
            Else
                sJson.AppendLine()
            End If

        Next oItem

        sJson.Append(vbTab, repeatCount:=nLevel - 1).Append("}")

        Return sJson.ToString()

    End Function

    Private Function Array2Json(oArray As Object, Optional nLevel As Long = 1) As String
        Dim sJson As New StringBuilder
        Dim oValue As Object
        Dim nCnt As Long

        sJson.Append(vbTab, repeatCount:=nLevel - 1).Append("[").AppendLine()

        For Each oValue In oArray
            nCnt += 1

            sJson.Append(JsonElement("", oValue, nLevel))

            If (nCnt < oArray.Length) Then
                sJson.Append(",").AppendLine()
            Else
                sJson.AppendLine()
            End If
        Next oValue

        sJson.Append(vbTab, repeatCount:=nLevel - 1).Append("]")

        Return sJson.ToString()

    End Function

    Private Function JsonElement(sKey As String, xValue As Object, Optional nLevel As Long = 0) As String
        Dim sJson As New StringBuilder

        sJson.Append(vbTab, repeatCount:=nLevel)
        If (sKey.Length > 0) Then
            sJson.Append("""" & sKey & """" & ":")
        End If

        If IsNothing(xValue) Then
            sJson.Append("null")
        ElseIf (IsArray(xValue)) Then
            sJson.AppendLine().Append(Array2Json(xValue, nLevel + 1))
        ElseIf (xValue.GetType Is GetType(Dictionary(Of String, Object))) Then
            sJson.AppendLine().Append(Dictionary2Json(xValue, nLevel + 1))
        Else
            Select Case TypeName(xValue)
                Case "String", "Date", "DateTime"
                    sJson.Append("""").Append(JsonEscapeCahr(xValue)).Append("""")
                Case Else
                    sJson.Append(xValue.ToString().ToLower())
            End Select
        End If

        Return sJson.ToString()

    End Function

    Private Function JsonEscapeCahr(sValue As String) As String

        Return sValue.Replace("\", "\\").
                        Replace("/", "\/").
                        Replace("""", "\""").
                        Replace(vbTab, "\t").
                        Replace(vbCr, "\r").
                        Replace(vbNewLine, "\n").
                        Replace(vbLf, "\f").
                        Replace(vbBack, "\b")
    End Function
End Class
