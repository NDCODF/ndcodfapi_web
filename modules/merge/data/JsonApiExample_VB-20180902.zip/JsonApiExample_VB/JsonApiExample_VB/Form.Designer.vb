﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form
    Inherits System.Windows.Forms.Form

    'Form 覆寫 Dispose 以清除元件清單。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    '為 Windows Form 設計工具的必要項
    Private components As System.ComponentModel.IContainer

    '注意: 以下為 Windows Form 設計工具所需的程序
    '可以使用 Windows Form 設計工具進行修改。
    '請勿使用程式碼編輯器進行修改。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.詳細資料 = New System.Windows.Forms.DataGridView()
        Me.姓名 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.電子郵件 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.電話 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.地址 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.生日 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.備註 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Writer_API = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.製表人 = New System.Windows.Forms.TextBox()
        Me.製作日期 = New System.Windows.Forms.DateTimePicker()
        Me.製作報表 = New System.Windows.Forms.Button()
        Me.Writer = New System.Windows.Forms.RadioButton()
        Me.Calc = New System.Windows.Forms.RadioButton()
        Me.Calc_API = New System.Windows.Forms.TextBox()
        CType(Me.詳細資料, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        '詳細資料
        '
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle2.Font = New System.Drawing.Font("細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.詳細資料.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.詳細資料.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.詳細資料.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.姓名, Me.電子郵件, Me.電話, Me.地址, Me.生日, Me.備註})
        Me.詳細資料.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter
        Me.詳細資料.Location = New System.Drawing.Point(14, 203)
        Me.詳細資料.Margin = New System.Windows.Forms.Padding(4)
        Me.詳細資料.MultiSelect = False
        Me.詳細資料.Name = "詳細資料"
        Me.詳細資料.RowTemplate.Height = 24
        Me.詳細資料.Size = New System.Drawing.Size(984, 219)
        Me.詳細資料.TabIndex = 4
        '
        '姓名
        '
        Me.姓名.Frozen = True
        Me.姓名.HeaderText = "姓名"
        Me.姓名.Name = "姓名"
        '
        '電子郵件
        '
        Me.電子郵件.Frozen = True
        Me.電子郵件.HeaderText = "電子郵件"
        Me.電子郵件.Name = "電子郵件"
        Me.電子郵件.Width = 200
        '
        '電話
        '
        Me.電話.Frozen = True
        Me.電話.HeaderText = "電話"
        Me.電話.Name = "電話"
        Me.電話.Width = 150
        '
        '地址
        '
        Me.地址.Frozen = True
        Me.地址.HeaderText = "地址"
        Me.地址.Name = "地址"
        Me.地址.Width = 300
        '
        '生日
        '
        Me.生日.Frozen = True
        Me.生日.HeaderText = "生日"
        Me.生日.Name = "生日"
        '
        '備註
        '
        Me.備註.Frozen = True
        Me.備註.HeaderText = "備註"
        Me.備註.Name = "備註"
        Me.備註.Width = 200
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("細明體", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Blue
        Me.Label1.Location = New System.Drawing.Point(14, 179)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(114, 20)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "詳細資料："
        '
        'Writer_API
        '
        Me.Writer_API.Location = New System.Drawing.Point(157, 9)
        Me.Writer_API.Name = "Writer_API"
        Me.Writer_API.ReadOnly = True
        Me.Writer_API.Size = New System.Drawing.Size(841, 31)
        Me.Writer_API.TabIndex = 1
        Me.Writer_API.TabStop = False
        Me.Writer_API.Text = "https://ndcodf.ossii.com.tw:443/lool/merge-to/de53db22-ac2f-11e8-95bd-00505691363" &
    "3"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(14, 93)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(109, 20)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "製作日期："
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(14, 138)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(109, 20)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "製 表 人："
        '
        '製表人
        '
        Me.製表人.Location = New System.Drawing.Point(111, 135)
        Me.製表人.Name = "製表人"
        Me.製表人.Size = New System.Drawing.Size(155, 31)
        Me.製表人.TabIndex = 3
        '
        '製作日期
        '
        Me.製作日期.Location = New System.Drawing.Point(111, 89)
        Me.製作日期.Name = "製作日期"
        Me.製作日期.Size = New System.Drawing.Size(155, 31)
        Me.製作日期.TabIndex = 2
        '
        '製作報表
        '
        Me.製作報表.Location = New System.Drawing.Point(877, 429)
        Me.製作報表.Name = "製作報表"
        Me.製作報表.Size = New System.Drawing.Size(121, 32)
        Me.製作報表.TabIndex = 5
        Me.製作報表.Text = "製作報表"
        Me.製作報表.UseVisualStyleBackColor = True
        '
        'Writer
        '
        Me.Writer.AutoSize = True
        Me.Writer.Location = New System.Drawing.Point(21, 12)
        Me.Writer.Name = "Writer"
        Me.Writer.Size = New System.Drawing.Size(130, 24)
        Me.Writer.TabIndex = 6
        Me.Writer.TabStop = True
        Me.Writer.Text = "Writer API"
        Me.Writer.UseVisualStyleBackColor = True
        '
        'Calc
        '
        Me.Calc.AutoSize = True
        Me.Calc.Location = New System.Drawing.Point(21, 49)
        Me.Calc.Name = "Calc"
        Me.Calc.Size = New System.Drawing.Size(110, 24)
        Me.Calc.TabIndex = 8
        Me.Calc.TabStop = True
        Me.Calc.Text = "Calc API"
        Me.Calc.UseVisualStyleBackColor = True
        '
        'Calc_API
        '
        Me.Calc_API.Location = New System.Drawing.Point(157, 46)
        Me.Calc_API.Name = "Calc_API"
        Me.Calc_API.ReadOnly = True
        Me.Calc_API.Size = New System.Drawing.Size(841, 31)
        Me.Calc_API.TabIndex = 7
        Me.Calc_API.TabStop = False
        Me.Calc_API.Text = "https://ndcodf.ossii.com.tw:443/lool/merge-to/ec02d688-ac2f-11e8-95bd-00505691363" &
    "3"
        '
        'Form
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(10.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.ClientSize = New System.Drawing.Size(1011, 468)
        Me.Controls.Add(Me.Calc)
        Me.Controls.Add(Me.Calc_API)
        Me.Controls.Add(Me.Writer)
        Me.Controls.Add(Me.製作報表)
        Me.Controls.Add(Me.製作日期)
        Me.Controls.Add(Me.製表人)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Writer_API)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.詳細資料)
        Me.Font = New System.Drawing.Font("細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "Form"
        Me.Text = "Json API 範例 for VB.NET "
        CType(Me.詳細資料, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents 詳細資料 As DataGridView
    Friend WithEvents Label1 As Label
    Friend WithEvents Writer_API As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents 製表人 As TextBox
    Friend WithEvents 製作日期 As DateTimePicker
    Friend WithEvents 製作報表 As Button
    Friend WithEvents 姓名 As DataGridViewTextBoxColumn
    Friend WithEvents 電子郵件 As DataGridViewTextBoxColumn
    Friend WithEvents 電話 As DataGridViewTextBoxColumn
    Friend WithEvents 地址 As DataGridViewTextBoxColumn
    Friend WithEvents 生日 As DataGridViewTextBoxColumn
    Friend WithEvents 備註 As DataGridViewTextBoxColumn
    Friend WithEvents Writer As RadioButton
    Friend WithEvents Calc As RadioButton
    Friend WithEvents Calc_API As TextBox
End Class
