﻿namespace jsonApiExample_CS
{
    partial class Form
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.Calc = new System.Windows.Forms.RadioButton();
            this.Calc_API = new System.Windows.Forms.TextBox();
            this.Writer = new System.Windows.Forms.RadioButton();
            this.製作報表 = new System.Windows.Forms.Button();
            this.製作日期 = new System.Windows.Forms.DateTimePicker();
            this.製表人 = new System.Windows.Forms.TextBox();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.Writer_API = new System.Windows.Forms.TextBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.詳細資料 = new System.Windows.Forms.DataGridView();
            this.姓名 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.電子郵件 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.電話 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.地址 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.生日 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.備註 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.詳細資料)).BeginInit();
            this.SuspendLayout();
            // 
            // Calc
            // 
            this.Calc.AutoSize = true;
            this.Calc.Location = new System.Drawing.Point(12, 49);
            this.Calc.Name = "Calc";
            this.Calc.Size = new System.Drawing.Size(110, 24);
            this.Calc.TabIndex = 19;
            this.Calc.TabStop = true;
            this.Calc.Text = "Calc API";
            this.Calc.UseVisualStyleBackColor = true;
            // 
            // Calc_API
            // 
            this.Calc_API.Location = new System.Drawing.Point(148, 46);
            this.Calc_API.Name = "Calc_API";
            this.Calc_API.ReadOnly = true;
            this.Calc_API.Size = new System.Drawing.Size(841, 31);
            this.Calc_API.TabIndex = 18;
            this.Calc_API.TabStop = false;
            this.Calc_API.Text = "https://ndcodf.ossii.com.tw:443/lool/merge-to/ec02d688-ac2f-11e8-95bd-00505691363" +
    "3";
            // 
            // Writer
            // 
            this.Writer.AutoSize = true;
            this.Writer.Location = new System.Drawing.Point(12, 12);
            this.Writer.Name = "Writer";
            this.Writer.Size = new System.Drawing.Size(130, 24);
            this.Writer.TabIndex = 17;
            this.Writer.TabStop = true;
            this.Writer.Text = "Writer API";
            this.Writer.UseVisualStyleBackColor = true;
            // 
            // 製作報表
            // 
            this.製作報表.Location = new System.Drawing.Point(868, 429);
            this.製作報表.Name = "製作報表";
            this.製作報表.Size = new System.Drawing.Size(121, 32);
            this.製作報表.TabIndex = 15;
            this.製作報表.Text = "製作報表";
            this.製作報表.UseVisualStyleBackColor = true;
            this.製作報表.Click += new System.EventHandler(this.製作報表_Click);
            // 
            // 製作日期
            // 
            this.製作日期.Location = new System.Drawing.Point(126, 89);
            this.製作日期.Name = "製作日期";
            this.製作日期.Size = new System.Drawing.Size(166, 31);
            this.製作日期.TabIndex = 11;
            // 
            // 製表人
            // 
            this.製表人.Location = new System.Drawing.Point(126, 135);
            this.製表人.Name = "製表人";
            this.製表人.Size = new System.Drawing.Size(166, 31);
            this.製表人.TabIndex = 12;
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Location = new System.Drawing.Point(5, 138);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(109, 20);
            this.Label4.TabIndex = 16;
            this.Label4.Text = "製 表 人：";
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Location = new System.Drawing.Point(5, 93);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(109, 20);
            this.Label3.TabIndex = 13;
            this.Label3.Text = "製作日期：";
            // 
            // Writer_API
            // 
            this.Writer_API.Location = new System.Drawing.Point(148, 9);
            this.Writer_API.Name = "Writer_API";
            this.Writer_API.ReadOnly = true;
            this.Writer_API.Size = new System.Drawing.Size(841, 31);
            this.Writer_API.TabIndex = 9;
            this.Writer_API.TabStop = false;
            this.Writer_API.Text = "https://ndcodf.ossii.com.tw:443/lool/merge-to/de53db22-ac2f-11e8-95bd-00505691363" +
    "3";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Label1.ForeColor = System.Drawing.Color.Blue;
            this.Label1.Location = new System.Drawing.Point(5, 179);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(114, 20);
            this.Label1.TabIndex = 10;
            this.Label1.Text = "詳細資料：";
            // 
            // 詳細資料
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.詳細資料.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.詳細資料.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.詳細資料.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.姓名,
            this.電子郵件,
            this.電話,
            this.地址,
            this.生日,
            this.備註});
            this.詳細資料.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.詳細資料.Location = new System.Drawing.Point(5, 203);
            this.詳細資料.Margin = new System.Windows.Forms.Padding(4);
            this.詳細資料.MultiSelect = false;
            this.詳細資料.Name = "詳細資料";
            this.詳細資料.RowTemplate.Height = 24;
            this.詳細資料.Size = new System.Drawing.Size(984, 219);
            this.詳細資料.TabIndex = 14;
            // 
            // 姓名
            // 
            this.姓名.Frozen = true;
            this.姓名.HeaderText = "姓名";
            this.姓名.Name = "姓名";
            // 
            // 電子郵件
            // 
            this.電子郵件.Frozen = true;
            this.電子郵件.HeaderText = "電子郵件";
            this.電子郵件.Name = "電子郵件";
            this.電子郵件.Width = 200;
            // 
            // 電話
            // 
            this.電話.Frozen = true;
            this.電話.HeaderText = "電話";
            this.電話.Name = "電話";
            this.電話.Width = 150;
            // 
            // 地址
            // 
            this.地址.Frozen = true;
            this.地址.HeaderText = "地址";
            this.地址.Name = "地址";
            this.地址.Width = 300;
            // 
            // 生日
            // 
            this.生日.Frozen = true;
            this.生日.HeaderText = "生日";
            this.生日.Name = "生日";
            // 
            // 備註
            // 
            this.備註.Frozen = true;
            this.備註.HeaderText = "備註";
            this.備註.Name = "備註";
            this.備註.Width = 200;
            // 
            // Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(998, 469);
            this.Controls.Add(this.Calc);
            this.Controls.Add(this.Calc_API);
            this.Controls.Add(this.Writer);
            this.Controls.Add(this.製作報表);
            this.Controls.Add(this.製作日期);
            this.Controls.Add(this.製表人);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.Writer_API);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.詳細資料);
            this.Font = new System.Drawing.Font("細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form";
            this.Text = "Json Api 範例 For C#.NET";
            ((System.ComponentModel.ISupportInitialize)(this.詳細資料)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.RadioButton Calc;
        internal System.Windows.Forms.TextBox Calc_API;
        internal System.Windows.Forms.RadioButton Writer;
        internal System.Windows.Forms.Button 製作報表;
        internal System.Windows.Forms.DateTimePicker 製作日期;
        internal System.Windows.Forms.TextBox 製表人;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.TextBox Writer_API;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.DataGridView 詳細資料;
        internal System.Windows.Forms.DataGridViewTextBoxColumn 姓名;
        internal System.Windows.Forms.DataGridViewTextBoxColumn 電子郵件;
        internal System.Windows.Forms.DataGridViewTextBoxColumn 電話;
        internal System.Windows.Forms.DataGridViewTextBoxColumn 地址;
        internal System.Windows.Forms.DataGridViewTextBoxColumn 生日;
        internal System.Windows.Forms.DataGridViewTextBoxColumn 備註;
    }
}

