﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Net;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace jsonApiExample_CS
{

    public partial class Form : System.Windows.Forms.Form
    {
        const long BUF_SIZE = 1024000;  // 1M
        public Form()
        {
            InitializeComponent();
        }

        private void 製作報表_Click(object sender, EventArgs e)
        {
            Dictionary<string, object> oDict = new Dictionary<string, object>();
            Dictionary<string, object> oRecord;
            object[] aData = { };
            string sJson, sApiUrl;

            oDict.Add("製作日期", 製作日期.Value);
            oDict.Add("製表人", 製表人.Text);
            foreach (DataGridViewRow oRow in 詳細資料.Rows)
            {
                if (oRow.IsNewRow) continue;    // 不理會新資料列

                Array.Resize(ref aData, aData.Length + 1);
                oRecord = new Dictionary<string, object>();
                // 依序取出每個欄位
                foreach (DataGridViewCell oCell in oRow.Cells)
                {
                    oRecord.Add(oCell.OwningColumn.Name, oCell.Value);
                }
                aData[aData.Length - 1] = oRecord;
            }

            oDict.Add("詳細資料", aData);
            oDict.Add("總筆數", aData.Length);

            sJson = Dictionary2Json(oDict);
            MessageBox.Show(sJson);
            if (Writer.Checked)
                sApiUrl = Writer_API.Text;
            else if (Calc.Checked)
                sApiUrl = Calc_API.Text;
            else
            {
                MessageBox.Show("請先選擇要製作 Writer 或 Calc 報表");
                return;
            }
            SendToAPI(sApiUrl, sJson);
        }

        // 傳送 Json 資料到 API 主機
        private bool SendToAPI(string sApiURL, string sJson)
        {
            HttpWebRequest oWebRequest;
            HttpWebResponse oWebResponse;
            FileStream oFileStream;
            SaveFileDialog oSaveFileDialog;
            byte[] sByteString;
            byte[] byteBuffer = new byte[BUF_SIZE];
            long nRead;
            int nPos;
            string sFilter, sSaveFile, sAttachment, sFileName, sExtension;

            sByteString = Encoding.UTF8.GetBytes(sJson);    // 轉成 UTF-8 字串

            // 送出資料
            oWebRequest = (HttpWebRequest)WebRequest.Create(sApiURL);
            oWebRequest.KeepAlive = true;
            oWebRequest.Method = "POST";
            oWebRequest.Timeout = 100000;    // 100 秒
            oWebRequest.ContentType = "application/json";
            oWebRequest.ContentLength = sByteString.Length;
            oWebRequest.GetRequestStream().Write(sByteString, 0, sByteString.Length);
            oWebRequest.GetRequestStream().Close();

            // 接收資料
            try
            {
                oWebResponse = (HttpWebResponse)oWebRequest.GetResponse();
            }
            catch (WebException exp)
            {
                MessageBox.Show(exp.Message, "傳送錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
                throw;
            }

            if (oWebResponse.StatusCode == HttpStatusCode.OK)
            {
                sFileName = "報表文件";
                switch (oWebResponse.ContentType)
                {
                    case "application/vnd.oasis.opendocument.text":
                        sFilter = "文字文件 (*.odt)|*.odt";
                        break;
                    case "application/vnd.oasis.opendocument.spreadsheet":
                        sFilter = "試算表 (*.ods)|*.ods";
                        break;
                    default:
                        sAttachment = oWebResponse.GetResponseHeader("Content-Disposition");
                        nPos = sAttachment.IndexOf("filename=");
                        sAttachment = sAttachment.Substring(nPos + 9).Trim('\"');
                        sFileName = Path.GetFileNameWithoutExtension(sAttachment);
                        sExtension = Path.GetExtension(sAttachment);
                        sFilter = "報表文件 (*" + sExtension + ")|*" + sExtension;
                        break;
                }
                oSaveFileDialog = new SaveFileDialog();
                oSaveFileDialog.Title = "儲存檔案";
                oSaveFileDialog.Filter = sFilter;
                oSaveFileDialog.FileName = sFileName;
                if (oSaveFileDialog.ShowDialog() != DialogResult.OK)
                {
                    oWebResponse.Close();
                    oWebResponse.Dispose();
                    MessageBox.Show("您已放棄存檔", "放棄", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return false;
                }
                sSaveFile = oSaveFileDialog.FileName;
                oSaveFileDialog.Dispose();

                oFileStream = new FileStream(sSaveFile, access: FileAccess.Write, mode: FileMode.Create);
                nRead = -1;
                while (nRead != 0)
                {
                    nRead = oWebResponse.GetResponseStream().Read(byteBuffer, 0, byteBuffer.Length);
                    if (nRead > 0)
                        oFileStream.Write(byteBuffer, 0, (int)nRead);
                }
                oFileStream.Close();
                oFileStream.Dispose();
                oWebResponse.GetResponseStream().Close();
                oWebResponse.GetResponseStream().Dispose();
            }
            oWebResponse.Close();
            oWebResponse.Dispose();

            MessageBox.Show("檔案儲存成功", "成功", MessageBoxButtons.OK, MessageBoxIcon.Information);

            return true;
        }

        private string Dictionary2Json(Dictionary<string, object> oDictionary, long nLevel = 1)
        {
            StringBuilder sJson = new StringBuilder();
            long nCnt = 0;

            sJson.Append('\t', repeatCount: (int)nLevel - 1).Append("{").AppendLine();

            foreach(KeyValuePair<String, Object> oItem in oDictionary)
            {
                nCnt++;
                sJson.Append(JsonElement(oItem.Key, oItem.Value, nLevel));
                if (nCnt < oDictionary.Count())
                {
                    sJson.Append(",");
                }
                sJson.AppendLine();
            }
            sJson.Append('\t', repeatCount: (int)nLevel - 1).Append("}");
            return sJson.ToString();
        }

        private string Array2Json(object[] oArray, long nLevel = 1)
        {
            StringBuilder sJson = new StringBuilder();
            long nCnt = 0;

            sJson.Append('\t', repeatCount: (int)nLevel - 1).Append("[").AppendLine();
            foreach (object oValue in oArray)
            {
                nCnt++;
                sJson.Append(JsonElement("", oValue, nLevel));
                if (nCnt < oArray.Length)
                {
                    sJson.Append(",");
                }
                sJson.AppendLine();
            }
            sJson.Append('\t', repeatCount: (int)nLevel - 1).Append("]");
            return sJson.ToString();
        }

        private string JsonElement(string sKey, object xValue, long nLevel = 0)
        {
            StringBuilder sJson = new StringBuilder();
            string sTypeName;

            sJson.Append('\t', repeatCount: (int)nLevel);
            if (sKey.Length > 0)
                sJson.Append("\"").Append(sKey).Append("\"").Append(":");

            if (xValue == null)
                sJson.Append("null");
            else if (xValue.GetType().IsArray)
                sJson.AppendLine().Append(Array2Json((object[])xValue, nLevel + 1));
            else if (xValue is Dictionary<string, object>)
                sJson.AppendLine().Append(Dictionary2Json((Dictionary<string, object>)xValue, nLevel + 1));
            else
            {
                sTypeName = xValue.GetType().Name;
                switch (sTypeName)
                {
                    case "String":
                    case "Date":
                    case "DateTime":
                        sJson.Append('\"').Append(JsonEscapeCahr(xValue.ToString())).Append('\"');
                        break;
                    default:
                        sJson.Append(xValue.ToString().ToLower());
                        break;
                }
                
            }
            return sJson.ToString();
        }
        private string JsonEscapeCahr(string sValue)
        {
            return sValue.Replace("\\", "\\\\")
                            .Replace("/", "\\" + "/")
                            .Replace("\"", "\\\"")
                            .Replace("\t", "\\" + "t")
                            .Replace("\r", "\\" + "r")
                            .Replace("\n", "\\" + "n")
                            .Replace("\f", "\\" + "f")
                            .Replace("\b", "\\" + "b");
        }
    }
}
